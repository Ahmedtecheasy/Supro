package com.ahmedtecheasy.skylivewallpapers.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WallpaperCatalogTest {
    @Test
    fun everyRequestedCollectionHasAtLeastOneOriginalDemoScene() {
        val representedCategories = WallpaperCatalog.wallpapers.map { it.category }.toSet()
        assertTrue(WallpaperCatalog.categories.containsAll(representedCategories))
        assertTrue(
            "Missing categories: ${WallpaperCatalog.categories - representedCategories}",
            representedCategories.containsAll(WallpaperCatalog.categories),
        )
    }

    @Test
    fun wallpaperIdsAreUniqueAndEveryLiveSceneUsesAnAnimatedStyle() {
        assertEquals(
            WallpaperCatalog.wallpapers.size,
            WallpaperCatalog.wallpapers.map { it.id }.toSet().size,
        )
        assertTrue(WallpaperCatalog.wallpapers.any { it.live && it.art == ArtStyle.STARFALL })
        assertTrue(WallpaperCatalog.wallpapers.any { it.live && it.art == ArtStyle.GALAXY })
        assertTrue(WallpaperCatalog.wallpapers.any { it.live && it.art == ArtStyle.RAIN })
        assertTrue(WallpaperCatalog.wallpapers.any { it.live && it.art == ArtStyle.AURORA })
        assertTrue(WallpaperCatalog.wallpapers.any { it.live && it.art == ArtStyle.OCEAN })
        assertTrue(WallpaperCatalog.wallpapers.any { it.live && it.art == ArtStyle.CLOUDS })
    }
}