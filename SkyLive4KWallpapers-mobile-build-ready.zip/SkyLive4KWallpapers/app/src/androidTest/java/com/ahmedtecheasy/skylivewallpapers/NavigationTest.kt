package com.ahmedtecheasy.skylivewallpapers

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NavigationTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun bottomNavigationOpensAllPrimaryScreens() {
        composeRule.onNodeWithText("A little sky, wherever you are.").assertExists()

        composeRule.onNodeWithText("Categories").performClick()
        composeRule.onNodeWithText("Find your atmosphere").assertExists()

        composeRule.onNodeWithText("Live").performClick()
        composeRule.onNodeWithText("Move with the sky").assertExists()

        composeRule.onNodeWithText("Favorites").performClick()
        composeRule.onNodeWithText("Your collection").assertExists()

        composeRule.onNodeWithText("Settings").performClick()
        composeRule.onNodeWithText("Make Sky Live yours").assertExists()
    }

    @Test
    fun openingFeaturedArtworkShowsPreviewAndWallpaperActions() {
        composeRule.onNodeWithText("Sky Afterglow").performClick()
        composeRule.onNodeWithText("Set wallpaper").assertExists()
        composeRule.onNodeWithText("2160 × 3840  ·  4K UHD").assertExists()
    }
}