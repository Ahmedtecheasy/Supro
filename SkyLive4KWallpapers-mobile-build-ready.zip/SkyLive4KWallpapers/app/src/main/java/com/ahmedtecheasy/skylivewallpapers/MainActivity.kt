package com.ahmedtecheasy.skylivewallpapers

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ahmedtecheasy.skylivewallpapers.art.WallpaperArtwork
import com.ahmedtecheasy.skylivewallpapers.data.Wallpaper
import com.ahmedtecheasy.skylivewallpapers.data.WallpaperActions
import com.ahmedtecheasy.skylivewallpapers.data.WallpaperCatalog
import com.ahmedtecheasy.skylivewallpapers.data.WallpaperStore
import com.ahmedtecheasy.skylivewallpapers.live.SkyLiveWallpaperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class MainTab(val label: String) {
    HOME("Home"), CATEGORIES("Categories"), LIVE("Live"), FAVORITES("Favorites"), SETTINGS("Settings"),
}

private data class SkyColors(
    val background: Color,
    val surface: Color,
    val elevated: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val outline: Color,
)

private val NightColors = SkyColors(
    background = Color(0xFF090D19), surface = Color(0xFF12182A), elevated = Color(0xFF1A2239),
    text = Color(0xFFF6F4FF), muted = Color(0xFF9BA5BE), accent = Color(0xFFB9A7FF),
    accentSoft = Color(0xFF30284D), outline = Color(0xFF29314A),
)
private val DayColors = SkyColors(
    background = Color(0xFFF6F7FC), surface = Color.White, elevated = Color(0xFFECEFFD),
    text = Color(0xFF172039), muted = Color(0xFF69728A), accent = Color(0xFF6455B8),
    accentSoft = Color(0xFFECE8FF), outline = Color(0xFFE2E5EF),
)
private val LocalMotionEnabled = compositionLocalOf { true }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        val store = WallpaperStore(applicationContext)
        setContent { SkyWallpaperApp(store) }
    }
}

@Composable
private fun SkyWallpaperApp(store: WallpaperStore) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    val scope = rememberCoroutineScope()
    var dark by remember { mutableStateOf(store.isDarkMode()) }
    var effects by remember { mutableStateOf(store.effectsEnabled()) }
    var tab by remember { mutableStateOf(MainTab.HOME) }
    var selected by remember { mutableStateOf<Wallpaper?>(null) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var showTargetPicker by remember { mutableStateOf(false) }
    var pendingWallpaper by remember { mutableStateOf<Wallpaper?>(null) }
    var favoritesVersion by remember { mutableIntStateOf(0) }
    var operationInProgress by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(store.downloadQuality()) }
    val colors = if (dark) NightColors else DayColors

    SideEffect {
        activity?.window?.let { window ->
            window.statusBarColor = android.graphics.Color.rgb(
                (colors.background.red * 255).toInt(),
                (colors.background.green * 255).toInt(),
                (colors.background.blue * 255).toInt(),
            )
            window.navigationBarColor = window.statusBarColor
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (dark) 0 else
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    fun openLivePicker(wallpaper: Wallpaper) {
        store.setLiveScene(wallpaper.art.name)
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(context, SkyLiveWallpaperService::class.java),
            )
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            runCatching { context.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
                .onFailure { toast(context, "Live wallpaper preview is unavailable on this device.") }
        }
    }

    fun download(wallpaper: Wallpaper) {
        if (operationInProgress) return
        operationInProgress = true
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) { WallpaperActions.saveToGallery(context, wallpaper, quality) }
            }.onSuccess {
                store.markDownloaded(wallpaper.id)
                favoritesVersion++
                toast(context, "Saved to Pictures / Sky Live Wallpapers")
            }.onFailure { toast(context, it.message ?: "Couldn't save this wallpaper.") }
            operationInProgress = false
        }
    }

    fun setWallpaper(wallpaper: Wallpaper, target: WallpaperActions.Target) {
        if (operationInProgress) return
        operationInProgress = true
        showTargetPicker = false
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) { WallpaperActions.setAsWallpaper(context, wallpaper, target, quality) }
            }.onSuccess {
                toast(context, "Wallpaper applied.")
            }.onFailure { toast(context, it.message ?: "Couldn't apply wallpaper.") }
            operationInProgress = false
        }
    }

    CompositionLocalProvider(LocalMotionEnabled provides effects) {
        MaterialTheme(
            colorScheme = androidx.compose.material3.lightColorScheme(
                primary = colors.accent, secondary = colors.accent, background = colors.background,
                surface = colors.surface, onPrimary = if (dark) Color(0xFF171329) else Color.White,
                onSurface = colors.text, onBackground = colors.text,
            ),
        ) {
          Surface(modifier = Modifier.fillMaxSize(), color = colors.background) {
            if (selected != null) {
                WallpaperDetailScreen(
                    wallpaper = selected!!,
                    colors = colors,
                    favorite = store.isFavorite(selected!!.id),
                    busy = operationInProgress,
                    onBack = { selected = null },
                    onFavorite = {
                        store.toggleFavorite(selected!!.id)
                        favoritesVersion++
                    },
                    onDownload = { download(selected!!) },
                    onShare = {
                        val shareTarget = selected!!
                        scope.launch {
                            runCatching { WallpaperActions.share(context, shareTarget, quality) }
                                .onFailure { toast(context, "Sharing isn't available right now.") }
                        }
                    },
                    onSet = {
                        if (selected!!.live) openLivePicker(selected!!) else {
                            pendingWallpaper = selected
                            showTargetPicker = true
                        }
                    },
                )
            } else {
                Scaffold(
                    containerColor = colors.background,
                    bottomBar = {
                        NavigationBar(
                            containerColor = colors.surface,
                            tonalElevation = 0.dp,
                        ) {
                            MainTab.entries.forEach { item ->
                                NavigationBarItem(
                                    selected = tab == item,
                                    onClick = {
                                        tab = item
                                        if (item != MainTab.CATEGORIES) selectedCategory = null
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = when (item) {
                                                MainTab.HOME -> Icons.Default.Home
                                                MainTab.CATEGORIES -> Icons.Default.Star
                                                MainTab.LIVE -> Icons.Default.Star
                                                MainTab.FAVORITES -> Icons.Default.FavoriteBorder
                                                MainTab.SETTINGS -> Icons.Default.Settings
                                            },
                                            contentDescription = item.label,
                                            modifier = Modifier.size(21.dp),
                                        )
                                    },
                                    label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = colors.accent,
                                        selectedTextColor = colors.accent,
                                        indicatorColor = colors.accentSoft,
                                        unselectedIconColor = colors.muted,
                                        unselectedTextColor = colors.muted,
                                    ),
                                )
                            }
                        }
                    },
                ) { padding ->
                    AnimatedContent(
                        targetState = tab,
                        modifier = Modifier.fillMaxSize().padding(padding),
                        label = "screen-transition",
                    ) { page ->
                        when (page) {
                            MainTab.HOME -> HomeScreen(
                                colors, query, { query = it }, { selected = it }, { tab = MainTab.CATEGORIES },
                            )
                            MainTab.CATEGORIES -> CategoriesScreen(
                                colors, selectedCategory, { selectedCategory = it }, { selected = it },
                            )
                            MainTab.LIVE -> LiveScreen(colors, { wallpaper ->
                                store.setLiveScene(wallpaper.art.name)
                                selected = wallpaper
                            })
                            MainTab.FAVORITES -> FavoritesScreen(
                                colors,
                                WallpaperCatalog.wallpapers.filter { store.isFavorite(it.id) },
                                WallpaperCatalog.wallpapers.filter { it.id in store.downloaded() },
                                favoritesVersion,
                                { selected = it },
                            )
                            MainTab.SETTINGS -> SettingsScreen(
                                colors = colors,
                                darkMode = dark,
                                effects = effects,
                                quality = quality,
                                onDarkMode = {
                                    dark = it
                                    store.setDarkMode(it)
                                },
                                onEffects = {
                                    effects = it
                                    store.setEffectsEnabled(it)
                                },
                                onQuality = {
                                    quality = it
                                    store.setDownloadQuality(it)
                                },
                            )
                        }
                    }
                }
            }
          }
        }
    }

    if (showTargetPicker && pendingWallpaper != null) {
        AlertDialog(
            onDismissRequest = { showTargetPicker = false },
            containerColor = colors.surface,
            title = { Text("Set wallpaper", color = colors.text, fontWeight = FontWeight.SemiBold) },
            text = { Text("Choose where to apply ${pendingWallpaper!!.title}.", color = colors.muted) },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { setWallpaper(pendingWallpaper!!, WallpaperActions.Target.HOME) }) {
                        Text("Home", color = colors.accent)
                    }
                    TextButton(onClick = { setWallpaper(pendingWallpaper!!, WallpaperActions.Target.LOCK) }) {
                        Text("Lock", color = colors.accent)
                    }
                    TextButton(onClick = { setWallpaper(pendingWallpaper!!, WallpaperActions.Target.BOTH) }) {
                        Text("Both", color = colors.accent)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showTargetPicker = false }) { Text("Cancel", color = colors.muted) }
            },
        )
    }
}

@Composable
private fun HomeScreen(
    colors: SkyColors,
    query: String,
    onQuery: (String) -> Unit,
    onOpen: (Wallpaper) -> Unit,
    onCategories: () -> Unit,
) {
    val results = remember(query) {
        if (query.isBlank()) emptyList() else WallpaperCatalog.wallpapers.filter {
            it.title.contains(query, true) || it.category.contains(query, true)
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        item {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp)) {
                BrandHeader(colors)
                Spacer(Modifier.height(20.dp))
                SearchField(query, onQuery, colors)
            }
        }
        if (query.isNotBlank()) {
            item {
                SectionTitle("Search results", "${results.size} wallpapers", colors)
                if (results.isEmpty()) {
                    EmptyState("No skies found", "Try a name like “Aurora” or a category such as “Ocean”.", colors)
                } else {
                    WallpaperGrid(results, colors, onOpen, Modifier.height((results.size / 2 * 205 + 230).coerceAtLeast(430).dp))
                }
            }
        } else {
            item {
                FeaturedCard(WallpaperCatalog.wallpapers.first(), colors, onOpen)
            }
            item {
                CategoryStrip(colors, onCategories)
            }
            item {
                ShelfSection("Latest wallpapers", "FRESHLY ADDED", WallpaperCatalog.wallpapers.take(8).reversed(), colors, onOpen)
            }
            item {
                ShelfSection("Popular right now", "LOVED BY SKY WATCHERS", WallpaperCatalog.wallpapers.drop(4).take(8), colors, onOpen)
            }
            item {
                ShelfSection(
                    "Live wallpapers", "MOTION FOR YOUR HOME SCREEN",
                    WallpaperCatalog.wallpapers.filter { it.live }, colors, onOpen,
                )
            }
        }
    }
}

@Composable
private fun BrandHeader(colors: SkyColors) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(43.dp).clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF6A65C9), Color(0xFF87BFD0)))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.Star, null, tint = Color.White, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("SKY LIVE", color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
            Text("4K WALLPAPERS", color = colors.muted, fontSize = 9.sp, letterSpacing = 1.25.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.clip(CircleShape).background(colors.elevated).padding(horizontal = 11.dp, vertical = 7.dp),
        ) {
            Text("4K", color = colors.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = .7.sp)
        }
    }
}

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit, colors: SkyColors) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(17.dp))
            .background(colors.surface).padding(horizontal = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Default.Search, null, tint = colors.muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = colors.text, fontSize = 14.sp),
            cursorBrush = Brush.verticalGradient(listOf(colors.accent, colors.accent)),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text("Find your next wallpaper", color = colors.muted, fontSize = 14.sp)
                    inner()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun FeaturedCard(wallpaper: Wallpaper, colors: SkyColors, onOpen: (Wallpaper) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp)) {
        Text("A little sky, wherever you are.", color = colors.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
        Spacer(Modifier.height(5.dp))
        Text("Original scenes for your screen.", color = colors.muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Box(
            Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(25.dp))
                .clickable { onOpen(wallpaper) },
        ) {
            ArtCanvas(wallpaper, Modifier.fillMaxSize(), animated = true)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC080D1A)), startY = 140f)))
            Column(Modifier.align(Alignment.BottomStart).padding(19.dp)) {
                Text("EDITOR'S PICK", color = Color(0xFFE7D5A7), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Spacer(Modifier.height(5.dp))
                Text(wallpaper.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("${wallpaper.category}  ·  4K UHD", color = Color(0xFFD2D7E8), fontSize = 12.sp)
            }
            Box(
                Modifier.align(Alignment.TopEnd).padding(14.dp).clip(CircleShape)
                    .background(Color(0x663A3668)).padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text("FEATURED", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun CategoryStrip(colors: SkyColors, onCategories: () -> Unit) {
    Column {
        SectionTitle("Explore a mood", "18 COLLECTIONS", colors, onAction = onCategories)
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            items(WallpaperCatalog.categories) { category ->
                val wallpaper = WallpaperCatalog.wallpapers.firstOrNull { it.category == category }
                Surface(
                    onClick = onCategories,
                    color = colors.surface,
                    shape = RoundedCornerShape(30.dp),
                ) {
                    Row(
                        Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (wallpaper != null) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(colors.accent))
                            Spacer(Modifier.width(7.dp))
                        }
                        Text(category, color = colors.text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
private fun ShelfSection(
    title: String,
    eyebrow: String,
    wallpapers: List<Wallpaper>,
    colors: SkyColors,
    onOpen: (Wallpaper) -> Unit,
) {
    Column {
        SectionTitle(title, eyebrow, colors)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(wallpapers, key = { it.id }) { wallpaper ->
                WallpaperCard(wallpaper, colors, onOpen, Modifier.width(150.dp))
            }
        }
    }
}

@Composable
private fun SectionTitle(
    title: String,
    eyebrow: String,
    colors: SkyColors,
    onAction: (() -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = colors.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text(eyebrow, color = colors.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        }
        if (onAction != null) {
            TextButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                Text("See all", color = colors.accent, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun WallpaperCard(
    wallpaper: Wallpaper,
    colors: SkyColors,
    onOpen: (Wallpaper) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.clip(RoundedCornerShape(19.dp)).clickable { onOpen(wallpaper) },
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(.78f).clip(RoundedCornerShape(19.dp))) {
            ArtCanvas(wallpaper, Modifier.fillMaxSize())
            if (wallpaper.live) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(9.dp).size(27.dp).clip(CircleShape)
                        .background(Color(0x80302955)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(17.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(wallpaper.title, color = colors.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(wallpaper.category, color = colors.muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ArtCanvas(wallpaper: Wallpaper, modifier: Modifier = Modifier, animated: Boolean = false) {
    val motionEnabled = animated && LocalMotionEnabled.current
    val time = if (motionEnabled) {
        val transition = rememberInfiniteTransition(label = "wallpaper-motion")
        val animatedTime by transition.animateFloat(
            initialValue = 0f,
            targetValue = 6.28f,
            animationSpec = infiniteRepeatable(tween(8000, easing = FastOutSlowInEasing), RepeatMode.Restart),
            label = "wallpaper-time",
        )
        animatedTime
    } else 0f
    Canvas(modifier) {
        drawIntoCanvas { canvas ->
            WallpaperArtwork.draw(
                canvas.nativeCanvas,
                size.width.toInt().coerceAtLeast(1),
                size.height.toInt().coerceAtLeast(1),
                wallpaper.art,
                if (animated) time else 0f,
            )
        }
    }
}

@Composable
private fun CategoriesScreen(
    colors: SkyColors,
    selectedCategory: String?,
    onSelectCategory: (String?) -> Unit,
    onOpen: (Wallpaper) -> Unit,
) {
    val matches = WallpaperCatalog.wallpapers.filter { it.category == selectedCategory }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(top = 10.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (selectedCategory != null) {
                Icon(
                    Icons.Default.ArrowBack, "Back to categories",
                    tint = colors.text, modifier = Modifier.size(23.dp).clickable { onSelectCategory(null) },
                )
                Spacer(Modifier.width(12.dp))
            }
            Column {
                Text(selectedCategory ?: "Find your atmosphere", color = colors.text, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text(if (selectedCategory == null) "18 original collections" else "${matches.size} wallpaper${if (matches.size == 1) "" else "s"}",
                    color = colors.muted, fontSize = 12.sp)
            }
        }
        if (selectedCategory == null) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(WallpaperCatalog.categories) { category ->
                    val wallpaper = WallpaperCatalog.wallpapers.firstOrNull { it.category == category } ?: WallpaperCatalog.wallpapers.last()
                    Box(Modifier.fillMaxWidth().height(155.dp).clip(RoundedCornerShape(21.dp)).clickable { onSelectCategory(category) }) {
                        ArtCanvas(wallpaper, Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC070B17)), startY = 80f)))
                        Column(Modifier.align(Alignment.BottomStart).padding(13.dp)) {
                            Text(category, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (category == "Live Wallpapers") "Animated scenes" else "Explore collection",
                                color = Color(0xFFD8DBE8), fontSize = 10.sp)
                        }
                    }
                }
            }
        } else {
            if (matches.isEmpty()) EmptyState("More scenes soon", "This collection is ready for new artwork.", colors)
            else WallpaperGrid(matches, colors, onOpen, Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun WallpaperGrid(
    wallpapers: List<Wallpaper>,
    colors: SkyColors,
    onOpen: (Wallpaper) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(13.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        items(wallpapers, key = { it.id }) { wallpaper -> WallpaperCard(wallpaper, colors, onOpen) }
    }
}

@Composable
private fun LiveScreen(colors: SkyColors, onOpen: (Wallpaper) -> Unit) {
    val liveWallpapers = WallpaperCatalog.wallpapers.filter { it.live }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 25.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
    ) {
        item {
            Text("Move with the sky", color = colors.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("Animated directly by Android on your home screen.", color = colors.muted, fontSize = 13.sp)
            Spacer(Modifier.height(9.dp))
        }
        items(liveWallpapers, key = { it.id }) { wallpaper ->
            Box(
                Modifier.fillMaxWidth().height(236.dp).clip(RoundedCornerShape(25.dp)).clickable { onOpen(wallpaper) },
            ) {
                ArtCanvas(wallpaper, Modifier.fillMaxSize(), animated = true)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDB070B17)), startY = 130f)))
                Row(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(17.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("LIVE SCENE", color = Color(0xFFDCCBFF), fontSize = 9.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text(wallpaper.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(liveEffectDescription(wallpaper), color = Color(0xFFD4D8E7), fontSize = 12.sp)
                    }
                    Box(Modifier.size(43.dp).clip(CircleShape).background(Color(0x995B51A2)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
        item {
            Surface(color = colors.surface, shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, null, tint = colors.accent, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Choose a scene to preview and apply it with Android's live wallpaper picker.", color = colors.muted, fontSize = 12.sp, lineHeight = 17.sp)
                }
            }
        }
    }
}

private fun liveEffectDescription(wallpaper: Wallpaper): String = when (wallpaper.art.name) {
    "CLOUDS" -> "Slow drifting clouds"
    "OCEAN" -> "Soft animated ocean"
    "STARFALL" -> "Falling stars and soft glimmers"
    "GALAXY" -> "Orbiting nebula particles"
    "RAIN" -> "Gentle animated rain"
    else -> "Aurora and moving particles"
}

@Composable
private fun FavoritesScreen(
    colors: SkyColors,
    favorites: List<Wallpaper>,
    downloads: List<Wallpaper>,
    @Suppress("UNUSED_PARAMETER") refresh: Int,
    onOpen: (Wallpaper) -> Unit,
) {
    var showingDownloads by remember { mutableStateOf(false) }
    val list = if (showingDownloads) downloads else favorites
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(top = 14.dp)) {
        Text("Your collection", color = colors.text, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        Text("Saved on this device", color = colors.muted, fontSize = 12.sp, modifier = Modifier.padding(start = 20.dp, top = 4.dp, bottom = 15.dp))
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterPill("Favorites", !showingDownloads, colors) { showingDownloads = false }
            FilterPill("Downloaded", showingDownloads, colors) { showingDownloads = true }
        }
        Spacer(Modifier.height(9.dp))
        if (list.isEmpty()) {
            EmptyState(
                if (showingDownloads) "Nothing offline yet" else "Your saved skies live here",
                if (showingDownloads) "Download a wallpaper to keep it in your gallery for offline use."
                else "Tap the heart on any wallpaper to add it to this collection.",
                colors,
            )
        } else {
            WallpaperGrid(list, colors, onOpen, Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun FilterPill(label: String, selected: Boolean, colors: SkyColors, onClick: () -> Unit) {
    Surface(onClick = onClick, color = if (selected) colors.accentSoft else colors.surface, shape = RoundedCornerShape(24.dp)) {
        Text(
            label,
            color = if (selected) colors.accent else colors.muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 10.dp),
        )
    }
}

@Composable
private fun SettingsScreen(
    colors: SkyColors,
    darkMode: Boolean,
    effects: Boolean,
    quality: String,
    onDarkMode: (Boolean) -> Unit,
    onEffects: (Boolean) -> Unit,
    onQuality: (String) -> Unit,
) {
    var infoDialog by remember { mutableStateOf<String?>(null) }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 25.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Settings", color = colors.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Make Sky Live yours", color = colors.muted, fontSize = 13.sp)
            Spacer(Modifier.height(9.dp))
        }
        item {
            SettingGroup("APPEARANCE", colors) {
                SettingSwitch("Dark appearance", "A comfortable night-sky palette", darkMode, colors, onDarkMode)
            }
        }
        item {
            SettingGroup("WALLPAPER", colors) {
                SettingSwitch("Motion effects", "Animated details in previews and live scenes", effects, colors, onEffects)
                HorizontalDivider(color = colors.outline.copy(alpha = .7f))
                Column(Modifier.fillMaxWidth().padding(vertical = 13.dp)) {
                    Text("Download quality", color = colors.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Original procedural art; choose an export size.", color = colors.muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterPill("Standard", quality == "Standard", colors) { onQuality("Standard") }
                        FilterPill("4K UHD", quality == "4K", colors) { onQuality("4K") }
                    }
                }
            }
        }
        item {
            SettingGroup("ABOUT", colors) {
                SettingAction("Privacy policy", "Browse without an account or tracking", colors) {
                    infoDialog = "Privacy policy\n\nSky Live stores favorites, settings, and download references locally on this device. It does not require an account and this demo app does not send personal data to a server. Wallpaper downloads are saved to Pictures / Sky Live Wallpapers when you request them."
                }
                HorizontalDivider(color = colors.outline.copy(alpha = .7f))
                SettingAction("Terms of use", "Original demo artwork", colors) {
                    infoDialog = "Terms of use\n\nThe bundled demo scenes are procedurally generated original artwork. You may use downloaded demo images as personal device wallpapers. This starter app does not include a third-party content catalog or commercial image feed."
                }
                HorizontalDivider(color = colors.outline.copy(alpha = .7f))
                SettingAction("About Sky Live", "Version 1.0.0 · Ad integration disabled", colors) {
                    infoDialog = "Sky Live 4K Wallpapers\nVersion 1.0.0\n\nA privacy-first wallpaper app starter. Optional ad integration is not enabled."
                }
            }
        }
    }
    if (infoDialog != null) {
        AlertDialog(
            onDismissRequest = { infoDialog = null },
            containerColor = colors.surface,
            title = { Text(infoDialog!!.substringBefore("\n"), color = colors.text, fontWeight = FontWeight.SemiBold) },
            text = { Text(infoDialog!!.substringAfter("\n\n", ""), color = colors.muted, fontSize = 13.sp, lineHeight = 19.sp) },
            confirmButton = { TextButton(onClick = { infoDialog = null }) { Text("Done", color = colors.accent) } },
        )
    }
}

@Composable
private fun SettingGroup(title: String, colors: SkyColors, content: @Composable () -> Unit) {
    Column {
        Text(title, color = colors.muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 4.dp, bottom = 7.dp))
        Surface(color = colors.surface, shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(horizontal = 15.dp)) { content() }
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    colors: SkyColors,
    onChecked: (Boolean) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = colors.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = colors.muted, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = colors.accent),
        )
    }
}

@Composable
private fun SettingAction(title: String, subtitle: String, colors: SkyColors, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp)) {
        Text(title, color = colors.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = colors.muted, fontSize = 11.sp)
    }
}

@Composable
private fun EmptyState(title: String, message: String, colors: SkyColors) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 38.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(58.dp).clip(CircleShape).background(colors.elevated), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Star, null, tint = colors.accent, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = colors.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(5.dp))
        Text(message, color = colors.muted, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun WallpaperDetailScreen(
    wallpaper: Wallpaper,
    colors: SkyColors,
    favorite: Boolean,
    busy: Boolean,
    onBack: () -> Unit,
    onFavorite: () -> Unit,
    onDownload: () -> Unit,
    onShare: () -> Unit,
    onSet: () -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        ArtCanvas(wallpaper, Modifier.fillMaxSize(), animated = true)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x55050813), Color.Transparent, Color(0xEE080C18)), startY = 0f)))
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CircleAction(Icons.Default.ArrowBack, "Back", colors, onBack)
            Spacer(Modifier.weight(1f))
            Text("WALLPAPER PREVIEW", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
            Spacer(Modifier.weight(1f))
            CircleAction(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite", colors, onFavorite)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 18.dp),
        ) {
            Text(wallpaper.title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("${wallpaper.category}  ·  2160 × 3840  ·  4K UHD", color = Color(0xFFD5D7E5), fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onSet,
                    enabled = !busy,
                    modifier = Modifier.weight(1f).height(53.dp),
                    shape = RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE4DDFF), contentColor = Color(0xFF211B39)),
                ) {
                    Icon(if (wallpaper.live) Icons.Default.PlayArrow else Icons.Default.Check, null, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (wallpaper.live) "Preview live" else "Set wallpaper", fontWeight = FontWeight.SemiBold)
                }
                CircleAction(Icons.Default.FileDownload, "Download", colors, onDownload)
                CircleAction(Icons.Default.Share, "Share", colors, onShare)
            }
            if (busy) {
                Spacer(Modifier.height(9.dp))
                Text("Preparing your wallpaper…", color = Color(0xFFD5D7E5), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun CircleAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    colors: SkyColors,
    onClick: () -> Unit,
) {
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(Color(0x80303A58)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = Color.White, modifier = Modifier.size(20.dp))
    }
}

private fun toast(context: android.content.Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}