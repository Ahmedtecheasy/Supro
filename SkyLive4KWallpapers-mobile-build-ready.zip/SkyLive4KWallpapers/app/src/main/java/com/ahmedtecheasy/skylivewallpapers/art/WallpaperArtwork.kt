package com.ahmedtecheasy.skylivewallpapers.art

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import com.ahmedtecheasy.skylivewallpapers.data.ArtStyle
import kotlin.math.sin
import kotlin.random.Random

/**
 * Original, procedural illustrations used for the demo gallery and native live wallpaper.
 * No remote artwork, image scraping, or third-party image license is involved.
 */
object WallpaperArtwork {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    @Synchronized
    fun draw(canvas: Canvas, width: Int, height: Int, style: ArtStyle, time: Float = 0f) {
        if (width <= 0 || height <= 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val colors = palette(style)
        paint.shader = LinearGradient(0f, 0f, w * .18f, h, colors[0], colors[1], Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        if (style in setOf(ArtStyle.STARS, ArtStyle.STARFALL, ArtStyle.MOON, ArtStyle.GALAXY, ArtStyle.SPACE, ArtStyle.AMOLED)) {
            drawStars(canvas, w, h, style, time)
        }
        if (style == ArtStyle.GALAXY || style == ArtStyle.SPACE) drawGalaxy(canvas, w, h, time)
        if (style == ArtStyle.AURORA) drawAurora(canvas, w, h, time)
        if (style == ArtStyle.RAIN) drawRain(canvas, w, h, time)

        when (style) {
            ArtStyle.SUNRISE -> drawSun(canvas, w, h, .50f, .49f, .19f, 0xFFFFE8A7.toInt())
            ArtStyle.SUNSET -> drawSun(canvas, w, h, .71f, .49f, .17f, 0xFFFFBD80.toInt())
            ArtStyle.SKY, ArtStyle.CLOUDS -> {
                drawSun(canvas, w, h, .72f, .33f, .105f, 0xFFFFE9BA.toInt())
                drawCloud(canvas, w * .22f, h * .40f, w * .21f, time, 0xD9FFFFFF.toInt())
                drawCloud(canvas, w * .71f, h * .57f, w * .26f, time * .76f, 0x99FFFFFF.toInt())
            }
            ArtStyle.MOON -> {
                drawSun(canvas, w, h, .70f, .30f, .13f, 0xFFF5F0DB.toInt())
                paint.color = 0xFF243052.toInt()
                canvas.drawCircle(w * .75f, h * .275f, w * .115f, paint)
            }
            ArtStyle.MOUNTAINS -> drawMountains(canvas, w, h)
            ArtStyle.NATURE -> {
                drawMountains(canvas, w, h)
                drawForest(canvas, w, h)
            }
            ArtStyle.WATERFALL -> drawWaterfall(canvas, w, h, time)
            ArtStyle.OCEAN -> drawOcean(canvas, w, h, time)
            ArtStyle.ABSTRACT -> drawAbstract(canvas, w, h, time)
            ArtStyle.ANIMALS -> {
                drawMountains(canvas, w, h)
                drawBird(canvas, w * .54f, h * .54f, w * .15f)
            }
            ArtStyle.CARS -> drawCar(canvas, w, h)
            ArtStyle.AMOLED -> {
                paint.color = 0xFF151328.toInt()
                canvas.drawCircle(w * .72f, h * .44f, w * .31f, paint)
                paint.color = 0xFF8E78FF.toInt()
                canvas.drawCircle(w * .72f, h * .44f, w * .19f, paint)
                paint.color = 0xFF090A10.toInt()
                canvas.drawCircle(w * .72f, h * .44f, w * .175f, paint)
            }
            ArtStyle.MINIMAL -> {
                drawSun(canvas, w, h, .50f, .40f, .13f, 0xFFFFD7A1.toInt())
                paint.color = 0x55FFFFFF
                canvas.drawRoundRect(w * .22f, h * .71f, w * .78f, h * .715f, w * .02f, w * .02f, paint)
            }
            else -> Unit
        }
        if (style == ArtStyle.SUNRISE || style == ArtStyle.SUNSET || style == ArtStyle.SKY ||
            style == ArtStyle.CLOUDS || style == ArtStyle.AURORA
        ) drawMountains(canvas, w, h, distant = true)
    }

    private fun palette(style: ArtStyle): IntArray = when (style) {
        ArtStyle.SUNRISE -> intArrayOf(0xFF363D80.toInt(), 0xFFF59A89.toInt())
        ArtStyle.SUNSET -> intArrayOf(0xFF322E65.toInt(), 0xFFEF837B.toInt())
        ArtStyle.CLOUDS -> intArrayOf(0xFF536DA6.toInt(), 0xFFA8CCE5.toInt())
        ArtStyle.STARS, ArtStyle.STARFALL, ArtStyle.MOON, ArtStyle.AMOLED -> intArrayOf(0xFF10182F.toInt(), 0xFF24204C.toInt())
        ArtStyle.GALAXY -> intArrayOf(0xFF100F32.toInt(), 0xFF472878.toInt())
        ArtStyle.SPACE -> intArrayOf(0xFF070D21.toInt(), 0xFF172D5D.toInt())
        ArtStyle.MOUNTAINS -> intArrayOf(0xFF5B9AC0.toInt(), 0xFFB9C9D6.toInt())
        ArtStyle.NATURE -> intArrayOf(0xFF254C59.toInt(), 0xFF9BB58A.toInt())
        ArtStyle.WATERFALL -> intArrayOf(0xFF244F6C.toInt(), 0xFF79B4C1.toInt())
        ArtStyle.OCEAN -> intArrayOf(0xFF11365D.toInt(), 0xFF3E9DB3.toInt())
        ArtStyle.ABSTRACT -> intArrayOf(0xFF31346F.toInt(), 0xFF9A6DC6.toInt())
        ArtStyle.ANIMALS -> intArrayOf(0xFF384967.toInt(), 0xFFB2A787.toInt())
        ArtStyle.CARS -> intArrayOf(0xFF171D3A.toInt(), 0xFF7D356D.toInt())
        ArtStyle.MINIMAL -> intArrayOf(0xFF53647D.toInt(), 0xFFC6B6A5.toInt())
        ArtStyle.AURORA -> intArrayOf(0xFF071A33.toInt(), 0xFF224D68.toInt())
        ArtStyle.RAIN -> intArrayOf(0xFF182E49.toInt(), 0xFF517A91.toInt())
        ArtStyle.SKY -> intArrayOf(0xFF527AB6.toInt(), 0xFFE6A5A4.toInt())
    }

    private fun drawStars(canvas: Canvas, w: Float, h: Float, style: ArtStyle, time: Float) {
        val rng = Random(style.ordinal * 7919 + 41)
        repeat(90) { i ->
            val x = rng.nextFloat() * w
            val baseY = rng.nextFloat() * h * .75f
            val y = if (style == ArtStyle.STARFALL) (baseY + time * (45f + rng.nextFloat() * 70f)) % (h * .82f) else baseY
            val radius = (1.1f + rng.nextFloat() * 3.4f) * w / 1000f
            val pulse = 0.5f + 0.5f * sine(time * 1.4f + i.toFloat())
            val alpha = (145 + (100f * pulse).toInt()).coerceAtMost(255)
            paint.color = Color.argb(alpha, 236, 239, 255)
            canvas.drawCircle(x, y, radius, paint)
            if (style == ArtStyle.STARFALL && i % 11 == 0) {
                paint.color = 0xBBDDEBFF.toInt()
                paint.strokeWidth = radius * 1.2f
                canvas.drawLine(x, y, x - w * .035f, y - h * .018f, paint)
            }
        }
        if (style == ArtStyle.MOON) {
            paint.color = 0x20FFFFFF
            canvas.drawCircle(w * .70f, h * .30f, w * .18f, paint)
        }
    }

    private fun drawGalaxy(canvas: Canvas, w: Float, h: Float, time: Float) {
        val cx = w * .52f
        val cy = h * .43f
        for (i in 0..5) {
            paint.color = Color.argb(17 + i * 5, 226, 160, 255)
            canvas.drawOval(cx - w * (.42f - i * .025f), cy - h * (.10f - i * .008f),
                cx + w * (.42f - i * .025f), cy + h * (.10f - i * .008f), paint)
        }
        val rng = Random(9001)
        repeat(90) {
            val angle = rng.nextFloat() * 6.28f + time * .12f
            val radius = rng.nextFloat() * w * .39f
            paint.color = if (it % 3 == 0) 0xFFFFD8F6.toInt() else 0xFFB8CEFF.toInt()
            canvas.drawCircle(cx + cosine(angle) * radius, cy + sine(angle) * radius * .28f,
                w * (.001f + rng.nextFloat() * .002f), paint)
        }
        paint.color = 0xFFEDE1FF.toInt()
        canvas.drawCircle(cx, cy, w * .025f, paint)
    }

    private fun drawAurora(canvas: Canvas, w: Float, h: Float, time: Float) {
        for (band in 0..3) {
            val path = Path()
            val base = h * (.31f + band * .055f)
            for (step in 0..32) {
                val x = w * step / 32f
                val y = base + sine(step * .22f + time * .7f + band.toFloat()) * h * (.035f + band * .006f)
                if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = h * (.035f + band * .006f)
            paint.color = Color.argb(48, 81 + band * 20, 255, 198 + band * 10)
            paint.strokeCap = Paint.Cap.ROUND
            canvas.drawPath(path, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawSun(canvas: Canvas, w: Float, h: Float, x: Float, y: Float, radius: Float, color: Int) {
        paint.color = Color.argb(30, Color.red(color), Color.green(color), Color.blue(color))
        canvas.drawCircle(w * x, h * y, w * radius * 1.5f, paint)
        paint.color = color
        canvas.drawCircle(w * x, h * y, w * radius, paint)
    }

    private fun drawCloud(canvas: Canvas, x: Float, y: Float, width: Float, time: Float, color: Int) {
        val drift = sine(time * .22f) * width * .045f
        val r = width * .23f
        paint.color = color
        canvas.drawOval(x - width * .50f + drift, y, x + width * .50f + drift, y + r * .72f, paint)
        canvas.drawCircle(x - width * .20f + drift, y, r, paint)
        canvas.drawCircle(x + width * .08f + drift, y - r * .18f, r * 1.18f, paint)
        canvas.drawCircle(x + width * .34f + drift, y + r * .04f, r * .80f, paint)
    }

    private fun drawMountains(canvas: Canvas, w: Float, h: Float, distant: Boolean = false) {
        val path = Path().apply {
            moveTo(0f, h * .70f)
            lineTo(w * .19f, h * (if (distant) .52f else .58f))
            lineTo(w * .34f, h * .68f)
            lineTo(w * .57f, h * (if (distant) .47f else .55f))
            lineTo(w * .78f, h * .67f)
            lineTo(w, h * .51f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        paint.color = if (distant) 0x885A668F.toInt() else 0xFF27385B.toInt()
        canvas.drawPath(path, paint)
        if (!distant) {
            val foreground = Path().apply {
                moveTo(0f, h * .82f); lineTo(w * .29f, h * .66f); lineTo(w * .49f, h * .84f)
                lineTo(w * .74f, h * .63f); lineTo(w, h * .79f); lineTo(w, h); lineTo(0f, h); close()
            }
            paint.color = 0xFF17263F.toInt()
            canvas.drawPath(foreground, paint)
        }
    }

    private fun drawForest(canvas: Canvas, w: Float, h: Float) {
        val rng = Random(72)
        repeat(38) { i ->
            val x = i * w / 37f
            val base = h * (.77f + rng.nextFloat() * .18f)
            val height = h * (.07f + rng.nextFloat() * .09f)
            paint.color = if (i % 2 == 0) 0xFF193B35.toInt() else 0xFF245043.toInt()
            val path = Path().apply {
                moveTo(x, base); lineTo(x + w * .018f, base - height); lineTo(x + w * .038f, base); close()
            }
            canvas.drawPath(path, paint)
        }
    }

    private fun drawWaterfall(canvas: Canvas, w: Float, h: Float, time: Float) {
        paint.color = 0xFF1C4656.toInt()
        canvas.drawRect(0f, h * .45f, w * .29f, h, paint)
        canvas.drawRect(w * .72f, h * .39f, w, h, paint)
        paint.color = 0xFFB7EEF3.toInt()
        canvas.drawRoundRect(w * .34f, h * .31f, w * .69f, h * .84f, w * .08f, w * .08f, paint)
        paint.color = 0x8879D4E6.toInt()
        canvas.drawRect(w * (.46f + sine(time) * .015f), h * .32f, w * .55f, h * .82f, paint)
        drawOcean(canvas, w, h, time)
    }

    private fun drawOcean(canvas: Canvas, w: Float, h: Float, time: Float) {
        paint.shader = LinearGradient(0f, h * .60f, 0f, h, 0xFF236681.toInt(), 0xFF102F54.toInt(), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, h * .60f, w, h, paint)
        paint.shader = null
        for (i in 0..6) {
            val y = h * (.69f + i * .047f)
            paint.color = Color.argb(37 + i * 3, 157, 237, 237)
            paint.strokeWidth = h * .003f
            paint.style = Paint.Style.STROKE
            val path = Path()
            for (step in 0..20) {
                val x = w * step / 20f
                val waveY = y + sine(step * .46f + time + i.toFloat()) * h * .009f
                if (step == 0) path.moveTo(x, waveY) else path.lineTo(x, waveY)
            }
            canvas.drawPath(path, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawAbstract(canvas: Canvas, w: Float, h: Float, time: Float) {
        paint.color = 0x667DE6EF
        canvas.drawCircle(w * (.26f + sine(time) * .025f), h * .42f, w * .30f, paint)
        paint.color = 0x665B4DAD
        canvas.drawCircle(w * .77f, h * .55f, w * .36f, paint)
        paint.color = 0x55F2B1D7
        canvas.drawRoundRect(w * .16f, h * .62f, w * .82f, h * .68f, w * .08f, w * .08f, paint)
    }

    private fun drawRain(canvas: Canvas, w: Float, h: Float, time: Float) {
        paint.color = 0x334D799A
        canvas.drawRoundRect(w * .12f, h * .08f, w * .88f, h * .68f, w * .08f, w * .08f, paint)
        val rng = Random(425)
        repeat(115) { i ->
            val x = rng.nextFloat() * w
            val speed = 180f + rng.nextFloat() * 360f
            val y = (rng.nextFloat() * h + time * speed) % h
            paint.color = Color.argb(65 + (i % 5) * 17, 198, 224, 255)
            paint.strokeWidth = w * .0013f
            canvas.drawLine(x, y, x - w * .008f, y + h * .026f, paint)
        }
        paint.color = 0xFF152238.toInt()
        canvas.drawRect(0f, h * .82f, w, h, paint)
    }

    private fun drawBird(canvas: Canvas, x: Float, y: Float, size: Float) {
        paint.color = 0xFF171E2A.toInt()
        val path = Path().apply {
            moveTo(x - size, y); quadTo(x - size * .45f, y - size * .45f, x, y)
            quadTo(x + size * .45f, y - size * .45f, x + size, y)
            quadTo(x + size * .45f, y - size * .15f, x, y + size * .12f)
            quadTo(x - size * .45f, y - size * .15f, x - size, y); close()
        }
        canvas.drawPath(path, paint)
    }

    private fun drawCar(canvas: Canvas, w: Float, h: Float) {
        paint.color = 0xFF12172C.toInt()
        canvas.drawRoundRect(w * .17f, h * .65f, w * .85f, h * .79f, w * .07f, w * .07f, paint)
        val roof = Path().apply {
            moveTo(w * .32f, h * .65f); lineTo(w * .43f, h * .53f); lineTo(w * .67f, h * .53f)
            lineTo(w * .77f, h * .65f); close()
        }
        paint.color = 0xFFEC4B94.toInt()
        canvas.drawPath(roof, paint)
        paint.color = 0xFF151527.toInt()
        canvas.drawCircle(w * .31f, h * .78f, w * .07f, paint)
        canvas.drawCircle(w * .71f, h * .78f, w * .07f, paint)
        paint.color = 0xFFFFD99B.toInt()
        canvas.drawRect(w * .80f, h * .68f, w * .85f, h * .71f, paint)
    }

    private fun sine(value: Float): Float = sin(value.toDouble()).toFloat()
    private fun cosine(value: Float): Float = kotlin.math.cos(value.toDouble()).toFloat()
}