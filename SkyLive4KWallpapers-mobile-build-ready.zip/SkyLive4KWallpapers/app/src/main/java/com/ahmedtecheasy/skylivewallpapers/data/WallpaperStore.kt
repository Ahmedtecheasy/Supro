package com.ahmedtecheasy.skylivewallpapers.data

import android.content.Context
import android.content.SharedPreferences

class WallpaperStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("sky_live_preferences", Context.MODE_PRIVATE)

    fun favorites(): Set<String> = prefs.getStringSet(KEY_FAVORITES, emptySet())?.toSet() ?: emptySet()
    fun isFavorite(id: String): Boolean = id in favorites()
    fun toggleFavorite(id: String): Boolean {
        val updated = favorites().toMutableSet()
        val nowFavorite = if (updated.remove(id)) false else {
            updated.add(id)
            true
        }
        prefs.edit().putStringSet(KEY_FAVORITES, updated).apply()
        return nowFavorite
    }

    fun downloaded(): Set<String> = prefs.getStringSet(KEY_DOWNLOADED, emptySet())?.toSet() ?: emptySet()
    fun markDownloaded(id: String) {
        prefs.edit().putStringSet(KEY_DOWNLOADED, downloaded() + id).apply()
    }

    fun isDarkMode(): Boolean = prefs.getBoolean(KEY_DARK, true)
    fun setDarkMode(enabled: Boolean) = prefs.edit().putBoolean(KEY_DARK, enabled).apply()
    fun effectsEnabled(): Boolean = prefs.getBoolean(KEY_EFFECTS, true)
    fun setEffectsEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_EFFECTS, enabled).apply()
    fun downloadQuality(): String = prefs.getString(KEY_QUALITY, "4K") ?: "4K"
    fun setDownloadQuality(value: String) = prefs.edit().putString(KEY_QUALITY, value).apply()
    fun setLiveScene(style: String) = prefs.edit().putString(KEY_LIVE_SCENE, style).apply()
    fun liveScene(): String = prefs.getString(KEY_LIVE_SCENE, "AURORA") ?: "AURORA"

    private companion object {
        const val KEY_FAVORITES = "favorites"
        const val KEY_DOWNLOADED = "downloaded"
        const val KEY_DARK = "dark_mode"
        const val KEY_EFFECTS = "effects"
        const val KEY_QUALITY = "download_quality"
        const val KEY_LIVE_SCENE = "live_scene"
    }
}