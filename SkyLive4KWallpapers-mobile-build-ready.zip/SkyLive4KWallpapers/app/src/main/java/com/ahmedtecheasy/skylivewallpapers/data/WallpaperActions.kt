package com.ahmedtecheasy.skylivewallpapers.data

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.ahmedtecheasy.skylivewallpapers.art.WallpaperArtwork
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object WallpaperActions {
    enum class Target(val flags: Int) {
        HOME(WallpaperManager.FLAG_SYSTEM),
        LOCK(WallpaperManager.FLAG_LOCK),
        BOTH(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK),
    }

    fun saveToGallery(context: Context, wallpaper: Wallpaper, quality: String = "4K"): Uri {
        val (width, height) = sizeFor(quality)
        val bitmap = bitmapFor(wallpaper, width, height)
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "${wallpaper.id}-${quality.lowercase()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Sky Live Wallpapers")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Couldn't create a file in Pictures.")
        try {
            resolver.openOutputStream(uri)?.use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 94, output)) {
                    error("Wallpaper image couldn't be encoded.")
                }
            } ?: error("Couldn't open the new image file.")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            }
            return uri
        } catch (error: Throwable) {
            resolver.delete(uri, null, null)
            throw error
        } finally {
            bitmap.recycle()
        }
    }

    fun setAsWallpaper(context: Context, wallpaper: Wallpaper, target: Target, quality: String = "4K") {
        val (width, height) = sizeFor(quality)
        val bitmap = bitmapFor(wallpaper, width, height)
        try {
            WallpaperManager.getInstance(context).setBitmap(bitmap, null, true, target.flags)
        } finally {
            bitmap.recycle()
        }
    }

    suspend fun share(context: Context, wallpaper: Wallpaper, quality: String = "4K") {
        val uri = withContext(Dispatchers.IO) {
            createShareUri(context, wallpaper, quality)
        }
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, wallpaper.title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(sendIntent, "Share wallpaper"))
    }

    private fun createShareUri(context: Context, wallpaper: Wallpaper, quality: String): Uri {
        val (width, height) = sizeFor(quality)
        val bitmap = bitmapFor(wallpaper, width, height)
        val file = File(context.cacheDir, "shares").apply { mkdirs() }
            .resolve("${wallpaper.id}.jpg")
        try {
            val written = FileOutputStream(file).use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it)
            }
            if (!written) error("Wallpaper image couldn't be encoded.")
        } finally {
            bitmap.recycle()
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    }

    private fun bitmapFor(wallpaper: Wallpaper, width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        WallpaperArtwork.draw(android.graphics.Canvas(bitmap), width, height, wallpaper.art)
        return bitmap
    }

    private fun sizeFor(quality: String): Pair<Int, Int> =
        if (quality == "Standard") 1440 to 2560 else 2160 to 3840
}