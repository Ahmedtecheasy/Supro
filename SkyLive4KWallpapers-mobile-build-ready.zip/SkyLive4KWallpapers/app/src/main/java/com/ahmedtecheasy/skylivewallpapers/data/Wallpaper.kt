package com.ahmedtecheasy.skylivewallpapers.data

data class Wallpaper(
    val id: String,
    val title: String,
    val category: String,
    val art: ArtStyle,
    val live: Boolean = false,
)

enum class ArtStyle {
    SKY, SUNRISE, SUNSET, CLOUDS, STARS, MOON, GALAXY, SPACE,
    MOUNTAINS, NATURE, WATERFALL, OCEAN, ABSTRACT, ANIMALS,
    CARS, AMOLED, MINIMAL, AURORA, STARFALL, RAIN,
}

object WallpaperCatalog {
    val categories = listOf(
        "Amazing Sky", "Sunrise", "Sunset", "Clouds", "Stars", "Moon", "Galaxy",
        "Space", "Mountains", "Nature", "Waterfalls", "Ocean", "Abstract",
        "Animals", "Cars", "4K AMOLED", "Minimal", "Live Wallpapers",
    )

    val wallpapers = listOf(
        Wallpaper("sky-afterglow", "Sky Afterglow", "Amazing Sky", ArtStyle.SKY),
        Wallpaper("first-light", "First Light", "Sunrise", ArtStyle.SUNRISE),
        Wallpaper("golden-hour", "Golden Hour", "Sunset", ArtStyle.SUNSET),
        Wallpaper("cloud-drift", "Cloud Drift", "Clouds", ArtStyle.CLOUDS, true),
        Wallpaper("midnight-stars", "Midnight Stars", "Stars", ArtStyle.STARS),
        Wallpaper("moonlit", "Moonlit Quiet", "Moon", ArtStyle.MOON),
        Wallpaper("violet-orbit", "Violet Orbit", "Galaxy", ArtStyle.GALAXY),
        Wallpaper("deep-space", "Deep Space", "Space", ArtStyle.SPACE),
        Wallpaper("alpine-blue", "Alpine Blue", "Mountains", ArtStyle.MOUNTAINS),
        Wallpaper("wild-fern", "Wild Fern", "Nature", ArtStyle.NATURE),
        Wallpaper("silver-falls", "Silver Falls", "Waterfalls", ArtStyle.WATERFALL),
        Wallpaper("tide-glow", "Tide Glow", "Ocean", ArtStyle.OCEAN, true),
        Wallpaper("starfall", "Starfall", "Stars", ArtStyle.STARFALL, true),
        Wallpaper("nebula-drift", "Nebula Drift", "Galaxy", ArtStyle.GALAXY, true),
        Wallpaper("rain-on-glass", "Rain on Glass", "Clouds", ArtStyle.RAIN, true),
        Wallpaper("soft-current", "Soft Current", "Abstract", ArtStyle.ABSTRACT),
        Wallpaper("wild-spirit", "Wild Spirit", "Animals", ArtStyle.ANIMALS),
        Wallpaper("neon-drive", "Neon Drive", "Cars", ArtStyle.CARS),
        Wallpaper("black-ice", "Black Ice", "4K AMOLED", ArtStyle.AMOLED),
        Wallpaper("still-form", "Still Form", "Minimal", ArtStyle.MINIMAL),
        Wallpaper("aurora-veil", "Aurora Veil", "Live Wallpapers", ArtStyle.AURORA, true),
    )

    fun find(id: String): Wallpaper? = wallpapers.firstOrNull { it.id == id }
}