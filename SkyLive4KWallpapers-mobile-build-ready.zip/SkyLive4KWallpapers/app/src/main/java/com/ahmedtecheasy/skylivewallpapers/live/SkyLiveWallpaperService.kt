package com.ahmedtecheasy.skylivewallpapers.live

import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.ahmedtecheasy.skylivewallpapers.art.WallpaperArtwork
import com.ahmedtecheasy.skylivewallpapers.data.ArtStyle

class SkyLiveWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = SkyEngine()

    private inner class SkyEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var startTime = System.currentTimeMillis()
        private var surfaceWidth = 1
        private var surfaceHeight = 1

        private val drawFrame = object : Runnable {
            override fun run() {
                if (!visible) return
                draw()
                handler.removeCallbacks(this)
                handler.postDelayed(this, FRAME_MS)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (isVisible) drawFrame.run() else handler.removeCallbacks(drawFrame)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceWidth = width.coerceAtLeast(1)
            surfaceHeight = height.coerceAtLeast(1)
            draw()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawFrame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(drawFrame)
            super.onDestroy()
        }

        private fun draw() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    val preferences = getSharedPreferences("sky_live_preferences", MODE_PRIVATE)
                    val rawScene = preferences
                        .getString("live_scene", "AURORA") ?: "AURORA"
                    val style = runCatching { ArtStyle.valueOf(rawScene) }.getOrDefault(ArtStyle.AURORA)
                    val elapsed = (System.currentTimeMillis() - startTime) / 1000f
                    val motion = if (preferences.getBoolean("effects", true)) elapsed else 0f
                    WallpaperArtwork.draw(canvas, surfaceWidth, surfaceHeight, style, motion)
                }
            } catch (_: RuntimeException) {
                // A launcher may destroy the surface between callbacks; the next frame recovers.
            } finally {
                if (canvas != null) runCatching { holder.unlockCanvasAndPost(canvas) }
            }
        }
    }

    private companion object {
        const val FRAME_MS = 40L
    }
}