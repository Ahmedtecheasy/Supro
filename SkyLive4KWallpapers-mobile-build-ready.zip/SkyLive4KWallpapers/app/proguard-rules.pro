# Keep Android's wallpaper service discoverable in release builds.
-keep public class * extends android.service.wallpaper.WallpaperService { *; }