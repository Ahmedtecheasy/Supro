#!/usr/bin/env python3
"""Fast offline structural checks; not a substitute for Gradle or device tests."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app/src/main"
errors: list[str] = []

manifest = ET.parse(APP / "AndroidManifest.xml").getroot()
android_ns = "{http://schemas.android.com/apk/res/android}"
package = "com.ahmedtecheasy.skylivewallpapers"
application = manifest.find("application")
assert application is not None

permissions = {
    permission.get(android_ns + "name")
    for permission in manifest.findall("uses-permission")
}
if permissions != {"android.permission.SET_WALLPAPER"}:
    errors.append(f"Unexpected or missing permissions: {sorted(permissions)}")
services = application.findall("service")
if not any(s.get(android_ns + "name") == ".live.SkyLiveWallpaperService" for s in services):
    errors.append("WallpaperService is not registered in AndroidManifest.xml.")
if manifest.get("package") not in (None, package):
    errors.append("Unexpected manifest package.")

required_files = [
    "java/com/ahmedtecheasy/skylivewallpapers/MainActivity.kt",
    "java/com/ahmedtecheasy/skylivewallpapers/live/SkyLiveWallpaperService.kt",
    "java/com/ahmedtecheasy/skylivewallpapers/data/WallpaperActions.kt",
    "java/com/ahmedtecheasy/skylivewallpapers/art/WallpaperArtwork.kt",
    "res/xml/sky_live_wallpaper.xml",
    "res/mipmap-anydpi-v26/ic_launcher.xml",
    "res/drawable/ic_sky_mark.xml",
]
for relative in required_files:
    if not (APP / relative).is_file():
        errors.append(f"Missing required app file: {relative}")

gradle = (ROOT / "app/build.gradle.kts").read_text()
root_gradle = (ROOT / "build.gradle.kts").read_text()
checks = {
    "application ID": r'applicationId\s*=\s*"com\.ahmedtecheasy\.skylivewallpapers"',
    "namespace": r'namespace\s*=\s*"com\.ahmedtecheasy\.skylivewallpapers"',
    "compile SDK 36": r'compileSdk\s*=\s*36',
    "target SDK 36": r'targetSdk\s*=\s*36',
    "Java bytecode target 17": r'jvmTarget\s*=\s*"17"',
}
for label, pattern in checks.items():
    if not re.search(pattern, gradle):
        errors.append(f"Missing Android build setting: {label}")
for label, pattern in {
    "Android Gradle Plugin": r'com\.android\.application.*version\s+"8\.13\.0"',
    "Kotlin Android plugin": r'org\.jetbrains\.kotlin\.android.*version\s+"2\.2\.20"',
    "Kotlin Compose plugin": r'org\.jetbrains\.kotlin\.plugin\.compose.*version\s+"2\.2\.20"',
}.items():
    if not re.search(pattern, root_gradle):
        errors.append(f"Missing root plugin version: {label}")

for dependency in (
    "androidx.core:core-ktx",
    "androidx.activity:activity-compose",
    "androidx.compose.ui:ui",
    "androidx.compose.ui:ui-graphics",
    "androidx.compose.animation:animation",
    "androidx.compose.material3:material3",
    "androidx.compose.material:material-icons-core",
    "androidx.core:core-splashscreen",
    "kotlinx-coroutines-android",
    "junit:junit",
    "androidx.compose.ui:ui-test-junit4",
):
    if dependency not in gradle:
        errors.append(f"Missing required dependency: {dependency}")
for removed_dependency in (
    "navigation-compose",
    "lifecycle-ktx",
    "material-icons-extended",
    "espresso",
    "ui-tooling-preview",
):
    if removed_dependency in gradle:
        errors.append(f"Unneeded dependency remains: {removed_dependency}")

app_name = ET.parse(APP / "res/values/strings.xml").getroot()
labels = {item.get("name"): item.text for item in app_name.findall("string")}
if labels.get("app_name") != "Sky Live 4K Wallpapers":
    errors.append("Application label is not Sky Live 4K Wallpapers.")
if application.get(android_ns + "icon") != "@mipmap/ic_launcher":
    errors.append("Launcher icon is not set.")
for icon in ("ic_launcher.xml", "ic_launcher_round.xml"):
    if not (APP / "res/mipmap-anydpi-v26" / icon).is_file():
        errors.append(f"Adaptive launcher icon is missing: {icon}")

catalog_path = APP / "java/com/ahmedtecheasy/skylivewallpapers/data/Wallpaper.kt"
catalog = catalog_path.read_text()
categories_block = catalog.split("val categories = listOf(", 1)[1].split(")", 1)[0]
categories = re.findall(r'"([^"]+)"', categories_block)
catalog_entries = catalog.split("val wallpapers = listOf(", 1)[1]
for category in categories:
    if f'"{category}"' not in catalog_entries:
        errors.append(f"Category has no sample wallpaper: {category}")

art = (APP / "java/com/ahmedtecheasy/skylivewallpapers/art/WallpaperArtwork.kt").read_text()
for effect in ("drawCloud", "drawStars", "drawGalaxy", "drawRain", "drawAurora", "drawOcean"):
    if effect not in art:
        errors.append(f"Missing original art effect: {effect}")

actions = (APP / "java/com/ahmedtecheasy/skylivewallpapers/data/WallpaperActions.kt").read_text()
for api in (
    "MediaStore.Images.Media",
    "WallpaperManager.getInstance",
    "FileProvider.getUriForFile",
    "WallpaperManager.FLAG_LOCK",
    "WallpaperManager.FLAG_SYSTEM",
):
    if api not in actions:
        errors.append(f"Missing expected Android integration: {api}")

if errors:
    print("\n".join(f"FAIL: {item}" for item in errors))
    sys.exit(1)
print(f"PASS: structural checks; {len(categories)} categories; Android manifest and native feature hooks present.")