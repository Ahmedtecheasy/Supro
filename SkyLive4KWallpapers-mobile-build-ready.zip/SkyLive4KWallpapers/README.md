# Sky Live 4K Wallpapers

Android-native wallpaper app. The gallery, previews, and live scenes are generated with original Canvas artwork at runtime; there are no scraped images, remote image hosts, accounts, analytics, or ad SDKs. The Kotlin/Jetpack Compose app uses `WallpaperManager`, `WallpaperService`, `MediaStore`, and `FileProvider`.

## App structure

- `app/src/main/java/.../MainActivity.kt` — Home, Categories, Live, Favorites, Settings, search, preview, and set-wallpaper flows.
- `.../art/WallpaperArtwork.kt` — original procedural scenes, also drawn by the native live wallpaper.
- `.../data/WallpaperActions.kt` — 4K/standard image generation, MediaStore downloads, wallpaper apply, and safe image sharing.
- `.../live/SkyLiveWallpaperService.kt` — native Android animated wallpaper engine registered in the manifest.
- `.../data/WallpaperStore.kt` — on-device favorites, download index, theme, quality, and live scene preferences.
- Android API 36, min API 29, Java 17, package ID `com.ahmedtecheasy.skylivewallpapers`.

No broad media/storage permission is requested: downloads use Android's scoped `MediaStore` API. The app declares only the normal `SET_WALLPAPER` permission needed to apply static wallpapers. Favorites and settings stay in private app preferences. Downloaded JPEGs are saved under `Pictures/Sky Live Wallpapers` and remain in the device gallery for offline use. On Android 8–9 (below this app's min SDK) a different storage path would be needed; those versions are intentionally unsupported.

## Current build-environment limitation

This Replit workspace has Java 17 and Gradle 8.14.2, but no Android SDK installation: `ANDROID_HOME` and `ANDROID_SDK_ROOT` are unset, and `sdkmanager`, `adb`, and `android.jar` are absent. The attempted Gradle invocation stalled during Gradle daemon/settings startup and never reached Android plugin SDK discovery, so there is no emitted `SDK location not found` error and no APK/AAB was produced. The Gradle heap is capped for this 1.5 GB container; the Android build itself still needs to run in an SDK-equipped environment.

## Build and test

Install Android Studio or provide Android SDK platform 36 and Build Tools 36.0.0, then open this folder and accept Google's Android SDK license in Android Studio. Java 17 is required. This source checkout does not include Gradle wrapper scripts/JAR; in a build environment with Gradle 8.14.2 installed, generate the standard wrapper once (`gradle wrapper --gradle-version 8.14.2`) or run the commands below with the installed `gradle`. With the SDK installed and `ANDROID_SDK_ROOT` configured:

```bash
gradle testDebugUnitTest
gradle connectedDebugAndroidTest  # requires a running Android emulator/device
gradle assembleDebug
gradle bundleRelease
```

After generating the wrapper, replace `gradle` with `./gradlew`. Emulator/device verification is required for real wallpaper picker, lock-screen behavior, and gallery permissions. Applying to both Home and Lock depends on the Android launcher/device; Android may limit Lock-only wallpaper support.

## Signed Google Play AAB

Create a private upload keystore and keep it outside version control. Add a local, ignored `keystore.properties` file:

```properties
storeFile=upload-key.jks
storePassword=YOUR_LOCAL_KEYSTORE_PASSWORD
keyAlias=YOUR_UPLOAD_KEY_ALIAS
keyPassword=YOUR_LOCAL_KEY_PASSWORD
```

Place the keystore at the referenced local path. The release build applies signing only when all four values exist. Keep both files private and back up the keystore securely; never commit them. Then run `gradle bundleRelease`. The resulting bundle is `app/build/outputs/bundle/release/app-release.aab`. Google Play's current account setup, app signing, privacy disclosures, content rating, and store listing still need to be completed in Play Console; this source project does not publish the app.

## Release notes and remaining checks

- Live wallpapers are previewed/set through Android's system live-wallpaper picker. The service animates drifting clouds, falling stars, a rotating particle galaxy, rain, aurora, and ocean waves; Android pauses its frame loop when the wallpaper is not visible.
- Static wallpaper output is rendered on demand at 2160×3840 (RGB_565) or 1440×2560 and saved with MediaStore. No media permission prompt is needed at min API 29.
- The starter includes privacy and terms text suitable only for this offline demo. Replace/confirm the final legal text and add a public privacy-policy URL before Play release.
- AdMob is intentionally absent and disabled; no ads are shown.