# Sky Live 4K Wallpapers — Build APK using only a phone

This project includes a GitHub Actions workflow that builds the Android debug APK in GitHub's cloud. You do not need a PC or Android Studio.

## 1. Create a GitHub repository

On your phone, open GitHub in Chrome and sign in. Create a new repository, for example:

`SkyLive4KWallpapers`

For the easiest setup, keep the repository private.

## 2. Upload the project files

Extract this ZIP first. In the GitHub repository, choose **Add file → Upload files** and upload the **contents inside the `SkyLive4KWallpapers` folder**, including the `.github` folder.

Do not upload the outer `SkyLive4KWallpapers` folder as an extra nesting level.

After upload, the repository root should show:

- `.github`
- `app`
- `scripts`
- `build.gradle.kts`
- `gradle.properties`
- `settings.gradle.kts`

## 3. Run the cloud build

Open the repository's **Actions** tab.

Select **Build Android APK** → **Run workflow** → choose `main` → **Run workflow**.

If the workflow already started automatically after upload, just open that running workflow.

## 4. Download the APK

Wait for the workflow to finish with a green check. Open the successful run and scroll to **Artifacts**.

Download:

`SkyLive4KWallpapers-debug-apk`

Extract the downloaded artifact ZIP. Inside it is:

`app-debug.apk`

## 5. Install on Android

Tap `app-debug.apk`. If Android blocks it, open the prompt/settings for **Install unknown apps** and allow your browser or file manager to install APKs. Then return and tap the APK again.

The installed debug app uses the package ID:

`com.ahmedtecheasy.skylivewallpapers.debug`

## Important

This debug APK is for testing on your phone. For Google Play, create a signed release build/AAB and complete Play Console requirements. Do not upload private signing keys or passwords to GitHub.
